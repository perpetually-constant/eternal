# 第三方模块

在前面，我们介绍了一个优秀的第三方库 -- requests，本章再介绍两个第三方库：

- [celery](./celery.md)
- [click](./click.md)

其中：

- celery 是一个强大的分布式任务队列，通常用于实现异步任务；
- click 是快速创建命令行的神器；


