# 函数

本章讲解函数，包含以下部分：

* [定义函数](./func_definition.md)
* [函数参数](./func_parameter.md)

