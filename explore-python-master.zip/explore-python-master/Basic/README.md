# 基础

本章主要介绍两个方面的内容：

- [字符编码](./character_encoding.md)
- [输入和输出](./input_output.md)

其中，**字符编码**的概念很重要，不管你用的是 Python2 还是 Python3，亦或是 C++ 等其他编程语言，希望读者厘清这个概念，当遇到 UnicodeEncodeError 和 UnicodeDecodeError 时才能从容应对，而不是到处查找资料。


